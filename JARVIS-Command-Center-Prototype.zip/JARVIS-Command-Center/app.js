const micBtn=document.getElementById('micBtn');
const micLabel=document.getElementById('micLabel');
const voiceStatus=document.getElementById('voiceStatus');
const messages=document.getElementById('messages');
const input=document.getElementById('chatInput');
const form=document.getElementById('chatForm');

function addMessage(who,text){
  const el=document.createElement('div');
  el.className='message '+(who==='TU'?'user':'jarvis');
  const name=document.createElement('b'); name.textContent=who;
  const p=document.createElement('p'); p.textContent=text;
  el.append(name,p); messages.appendChild(el); messages.scrollTop=messages.scrollHeight;
}
function demoReply(text){
  const lower=text.toLowerCase();
  let reply='Am primit comanda. Interfața JARVIS este în modul prototip. În etapa următoare conectăm motorul AI securizat pentru răspunsuri reale și acțiuni autorizate.';
  if(lower.includes('bună dimineața')||lower.includes('hello')) reply='Bună. Sistemele de interfață sunt online. Sunt pregătit să continuăm configurarea.';
  if(lower.includes('kyro')) reply='KYRO Manager este planificat. Îl vom conecta la documentele, produsele și fluxurile brandului KYRO după configurarea nucleului AI.';
  if(lower.includes('ajutor')||lower.includes('help')) reply='Potrivit planului, voi avea module pentru organizare, KYRO, business, finanțe, trading și creare de conținut.';
  addMessage('JARVIS',reply);
  if('speechSynthesis' in window){const u=new SpeechSynthesisUtterance(reply);u.lang='ro-RO';u.rate=.9;u.pitch=.78;speechSynthesis.speak(u);}
}
form.addEventListener('submit',e=>{e.preventDefault();const t=input.value.trim();if(!t)return;addMessage('TU',t);input.value='';demoReply(t);});

const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
if(!SpeechRecognition){micBtn.addEventListener('click',()=>{voiceStatus.textContent='Recunoașterea vocală nu este disponibilă în acest browser. Poți scrie în câmpul de conversație; vom adăuga o integrare vocală compatibilă în versiunea conectată.';});}
else{
  const recognition=new SpeechRecognition(); recognition.interimResults=false; recognition.continuous=false; recognition.lang='ro-RO';
  recognition.onstart=()=>{micLabel.textContent='ASCULT...';voiceStatus.textContent='Te ascult. Vorbește acum.';};
  recognition.onend=()=>{micLabel.textContent='APASĂ ȘI VORBEȘTE';};
  recognition.onerror=()=>{voiceStatus.textContent='Nu am putut accesa microfonul. Verifică permisiunea browserului.';};
  recognition.onresult=e=>{const said=e.results[0][0].transcript;voiceStatus.textContent='Am auzit: '+said;addMessage('TU',said);demoReply(said);};
  micBtn.addEventListener('click',()=>{try{recognition.lang=/[ăâîșț]/i.test(document.documentElement.lang)?'ro-RO':'ro-RO';recognition.start();}catch(e){voiceStatus.textContent='Microfonul este deja activ.';}});
}
