J.A.R.V.I.S. COMMAND CENTER — PROTOTYPE 01

Ce conține:
- Interfață responsive pentru telefon și desktop.
- Stil vizual Iron Man + Command Center.
- Buton de microfon cu suport experimental Web Speech API, dacă browserul îl oferă.
- Răspuns vocal demonstrativ prin funcția de sinteză vocală a browserului.
- Manifest și service worker pentru instalare PWA.

IMPORTANT:
Aceasta este o interfață prototip. NU este încă conectată la un model AI, memorie persistentă, internet prin agent sau aplicații externe. Răspunsurile din chat sunt demonstrative. Nu introduce chei API, parole sau informații sensibile.

Test local pe Windows:
1. Instalează Python 3.
2. Deschide folderul proiectului.
3. În bara de adrese a folderului scrie cmd și apasă Enter.
4. Rulează: python -m http.server 8000
5. Pe laptop deschide: http://localhost:8000

Pentru test pe iPhone:
- Telefonul și laptopul trebuie să fie pe aceeași rețea Wi-Fi.
- Deschide Command Prompt și rulează: ipconfig
- Notează adresa IPv4 a laptopului (de exemplu 192.168.1.20).
- Pe iPhone, în Safari, deschide http://ADRESA-IP:8000
- Pentru instalare ca PWA și funcții complete, publică ulterior pe un hosting HTTPS. localhost pe laptop nu este accesibil de pe iPhone.

Instalare pe ecranul principal (după publicare HTTPS):
Safari > Share > Add to Home Screen.

Următoarea etapă de dezvoltare:
1. Backend securizat pentru modelul AI (cheia API rămâne pe server).
2. Memorie persistentă.
3. Voce bilingvă și selecție RO/EN.
4. Sistem de permisiuni și aprobare înainte de acțiuni externe.
5. Agenți specializați.
